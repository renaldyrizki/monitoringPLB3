<?php $__env->startSection('breadcrumbs'); ?>
    <?php echo Breadcrumbs::render('listTruck'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <div class="d-flex no-block">
                    <div class="ml-auto" style="margin-left: 0.2in; margin-bottom: 10px;">
                        <a href="<?php echo e(route('backend::tambahTruck')); ?>" class="btn btn-sm btn-success btn-md" href="#">
                            <i class="fa fa-plus"></i> Tambah Data Truk
                        </a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive m-t-20">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Aksi</th>
                                <th style="width: 20px">#</th>
                                <th>Nomor Truk</th>
                                <th>Perusahaan Trasnporter</th>
                                <th>Lampiran</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $no=1;?>
                        <?php $__empty_1 = true; $__currentLoopData = $data_truck; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $truck): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <a class="btn btn-success btn-xs" title="Ubah" href="#"> Lihat
                                        <i class="fa fa-eye"></i>
                                    </a>
                                    <a class="btn btn-info btn-xs" title="Ubah" href="#"> Ubah
                                        <i class="fa fa-pencil"></i>
                                    </a>
                                    <button class="btn btn-danger btn-xs" title="Hapus"> Hapus
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </td>
                                <td style="width: 20px">
                                    <?php echo e($no); ?>

                                </td>
                                <td>
                                    <?php echo e($truck->no_polisi); ?> 
                                </td>
                                <td>
                                    <?php echo e($truck->perusahaan_transporter); ?> 
                                </td>
                                <td>
                                    
                                    Tidak Ada
                                </td>
                                <td>
                                Tidak Lengkap 
                                </td>
                            </tr>
                            <?php $no++;?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6">
                                    Tidak ada data.
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <div class="col-md-12 text-center">
                    
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<style>
  table {
    /* border-collapse: collapse; */
  }
  
  table, th, td, tr, thead, tbody, .table>thead>tr>th {
    border-bottom: 1px solid black;
  }
  .table{
    width: 98%;
    max-width: 98%;
    margin-right: 1%;
    margin-left: 1%;
  }


  /* .table>thead>tr>th {
    border-bottom: 1px solid black;
  } */
</style>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<script type="text/javascript">
    function deleteData(id){
        console.log(id);
		$('#mdlHapus'+id).modal('show'); // show bootstrap modal
	}
</script>




<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.'.config('larakuy.theme_back').'.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>