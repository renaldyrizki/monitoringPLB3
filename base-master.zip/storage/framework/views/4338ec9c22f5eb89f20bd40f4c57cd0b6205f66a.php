<?php $__env->startSection('breadcrumbs'); ?>
    <?php echo Breadcrumbs::render('permitsControl_add'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <i class="icon fa fa-check"></i> <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <form action="<?php echo e(route('backend::permitsControl_update', ['id' => $data->id_permits])); ?>" class="form-horizontal" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <input name="_method" type="hidden" value="PATCH">
        <div class="form-group" row>
            <label for="jenis_perizinan" class="col-sm-2 control-label">Jenis Perizinan</label>
            <div class="col-sm-6">
                <select name="jenis_perizinan" class="form-control" required>
                    <?php $__currentLoopData = $jenis_perizinan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value=<?php echo e($key); ?> <?php echo e((!empty($data))? ($data->jenis_perizinan==$value) ? ' selected' : '' : ''); ?>><?php echo e($value); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="form-group">
            <label for="nama_perusahaan" class="col-sm-2 control-label">Nama Perusahaan</label>
            <div class="col-sm-6">
                <input required type="text" name="nama_perusahaan" id="nama_perusahaan" class="form-control" value="<?php echo e((!empty($data))? $data->nama_perusahaan : ''); ?>" placeholder="Nama Perusahaan">
            </div>
        </div>

        <div class="form-group" row>
            <label for="status_izin" class="col-sm-2 control-label">Status Izin</label>
            <div class="col-sm-6">
                <select name="status_izin" class="form-control" required>
                    <option value=1 <?php echo e((!empty($data))? ($data->status_izin==1) ? ' selected' : '' : ''); ?>>Aktif</option>
                    <option value=0 <?php echo e((!empty($data))? ($data->status_izin==0) ? ' selected' : '' : ''); ?>>Tidak Aktif</option>
                </select>
            </div>
        </div>

        <div class="form-group" row>
            <label for="dikeluarkan_oleh" class="col-sm-2 control-label">Dikeluarkan Oleh</label>
            <div class="col-sm-6">
                <select name="dikeluarkan_oleh" class="form-control" required>
                    <?php $__currentLoopData = $dikeluarkan_oleh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value=<?php echo e($key); ?> <?php echo e((!empty($data))? ($data->dikeluarkan_oleh==$value) ? ' selected' : '' : ''); ?>><?php echo e($value); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="form-group">
            <label for="no_surat_keputusan" class="col-sm-2 control-label">No Surat Keputusan</label>
            <div class="col-sm-6">
                <input required type="text" name="no_surat_keputusan" id="no_surat_keputusan" class="form-control" value="<?php echo e((!empty($data))? $data->no_surat_keputusan : ''); ?>" placeholder="No Surat Keputusan">
            </div>
        </div>
    
        <div class="form-group">
            <label for="tanggal_terbit_izin" class="col-sm-2 control-label">Tanggal Terbit Izin</label>
            <div class="col-sm-6">
                <input required type="text" name="tanggal_terbit_izin" data-date-format='yyyy-mm-dd' value="<?php echo e((!empty($data))? $data->tanggal_terbit : ''); ?>" class="form-control pull-right datepicker" id="tanggal_terbit_izin" placeholder="Tanggal Terbit Izin">
            </div>
        </div>

        <div class="form-group">
            <label for="tanggal_habis_izin" class="col-sm-2 control-label">Tanggal Habis Izin</label>
            <div class="col-sm-6">
                <input required type="text" name="tanggal_habis_izin" data-date-format='yyyy-mm-dd' value="<?php echo e((!empty($data))? $data->tanggal_habis_berlaku : ''); ?>" class="form-control pull-right datepicker" id="tanggal_habis_izin" placeholder="Tanggal Habis Izin">
            </div>
        </div>

        <div class="form-group">
            <label for="lampiran_dokumen" class="col-sm-2 control-label">Lampiran Dokumen</label>
            <div class="col-sm-6">
                <input type="file" accept="application/pdf" id="lampiran_dokumen" name="lampiran_dokumen" class="form-control">
                <?php if($data->lampiran_dokumen): ?>
                    <a href="<?php echo e(route('backend::permitsControl_download', ['id' => $data->id_permits])); ?>"><u>Download File Saat Ini</u></a><br>
                <?php endif; ?>
                <small>
                    <b>*Biarkan jika tidak akan diubah.</b><br>
                    <b>*File yang boleh diupload bertipe pdf dan berukuran maksimal 2mb.</b>
                </small>
            </div>
        </div>

        <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
                <input type="submit" class="btn btn-success btn-md" name="simpan" value="Simpan">
                <a class="btn btn-primary" role="button" onclick="resetform()">Reset</a>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <!-- bootstrap datepicker -->
    <link rel="stylesheet" href="<?php echo e(asset('bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <!-- bootstrap datepicker -->
    <script src="<?php echo e(asset('bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function () {
    
            var uploadField = document.getElementById("lampiran_dokumen");
    
            uploadField.onchange = function () {
                if (this.files[0].size > 2097152) {
                    this.value = "";
                };
            };
        });
    </script>
    <script>
    function resetform() {
        // document.getElementById("nomor_polisi").value = "";
        elements = [];
        elements = document.getElementsByClassName("form-control");
        for(var i=0; i<elements.length ; i++){
            console.log(elements[i].name);
            if (elements[i].name == 'jenis_perizinan' || elements[i].name == 'status_izin' || elements[i].name == 'dikeluarkan_oleh'){
                elements[i].selectedIndex = 0 ;
            }else{
                elements[i].value = "" ;
            }
        }
        
    }

    $(function () {
        //Date picker
        $('.datepicker').datepicker({
            autoclose: true
        })
    })
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>