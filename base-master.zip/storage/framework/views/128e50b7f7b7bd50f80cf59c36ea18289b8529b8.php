        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($item->hasChildren()): ?>
                <?php
                $active = '';
                foreach($item->children() as $children){
                    if(Request::url()==$children->url()){
                        $active = ' active';
                        break;
                    }
                }
                ?>
                <li class="treeview<?php echo e($active); ?>">
                    <a href="#">
                        <?php if($item->data('icon')): ?>
                            <i class="fa <?php echo e($item->data('icon')); ?>"></i> 
                        <?php endif; ?>
                        <span><?php echo $item->title; ?></span>
                        <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                        <?php echo $__env->make('layouts.backend.sidebar_item', ['items' => $item->children()], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </ul>
                </li>
            <?php else: ?>
                <li class="<?php echo e($active = (Request::url()==$item->url()) ? 'active' : ''); ?>">
                    <a href="<?php echo e($item->url()); ?>">
                        <?php if($item->data('icon')): ?>
                            <i class="fa <?php echo e($item->data('icon')); ?>"></i> 
                        <?php endif; ?>
                        <?php echo $item->title; ?>

                    </a>
                </li>
            <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>