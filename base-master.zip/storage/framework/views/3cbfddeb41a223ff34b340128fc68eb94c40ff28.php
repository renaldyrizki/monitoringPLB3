<?php $__env->startSection('breadcrumbs'); ?>
    <?php echo Breadcrumbs::render('penyimpananLimbahB3'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    
    

<form action="<?php echo e(route('backend::penyimpananLimbahB3_update', ['id' => $data->id_penyimpanan])); ?>" class="form-horizontal" method="post">
    <?php echo e(csrf_field()); ?>

    <input name="_method" type="hidden" value="PATCH">
    
        <div class="form-group" row>
            <label for="jenis_limbah" class="col-sm-2 control-label">Jenis Limbah</label>
            <div class="col-sm-6">
                <select name="jenis_limbah" class="form-control" required>
                    
                    <?php $__currentLoopData = $jenis_limbah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e((!empty($data))? ($data->jenis_limbah==$value) ? ' selected' : '' : ''); ?>><?php echo e($value); ?></option>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
    
        <div class="form-group">
            <label for="tanggal_penyimpanan" class="col-sm-2 control-label">Tanggal Penyimpanan</label>
            <div class="col-sm-6">
                <input required type="text" name="tanggal_penyimpanan" data-date-format='yyyy-mm-dd' value="<?php echo e((!empty($data))? $data->tanggal_penyimpanan : ''); ?>" class="form-control pull-right datepicker" id="tanggal_penyimpanan" placeholder="Tanggal Penyimpanan">
            </div>
        </div>

        <div class="form-group">
            <label for="masa_simpan" class="col-sm-2 control-label">Masa Simpan</label>
            <div class="col-sm-6">
                <input required type="number" min=1 name="masa_simpan" id="masa_simpan" class="form-control" value="<?php echo e((!empty($data))? $data->masa_simpan : ''); ?>" placeholder="Masa Simpan Dalam Hari">
            </div>
        </div>

        <div class="form-group">
            <label for="sumber_limbah" class="col-sm-2 control-label">Sumber Limbah</label>
            <div class="col-sm-6">
                <input required type="text" name="sumber_limbah" id="sumber_limbah" class="form-control" value="<?php echo e((!empty($data))? $data->sumber_limbah : ''); ?>" placeholder="Sumber Limbah">
            </div>
        </div>
        
        <div class="form-group">
            <label for="total_penyimpanan" class="col-sm-2 control-label">Total yang Disimpan</label>
            <div class="col-sm-4">
                <input required type="number" min=0 name="total_penyimpanan" id="total_penyimpanan" class="form-control" value="<?php echo e((!empty($data))? $data->total_penyimpanan : ''); ?>" placeholder="Berat dalam satuan KG">
            </div>
            <div class="col-sm-2">
                <select name="satuan" class="form-control" required>
                    <?php $__currentLoopData = $satuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($sat); ?>" <?php echo e((!empty($data))? ($data->satuan==$sat) ? ' selected' : '' : ''); ?>><?php echo e($sat); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
                <input type="submit" class="btn btn-success btn-md" name="simpan" value="Update">
                
                
                <a class="btn btn-primary" role="button" onclick="resetform()">Reset</a>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <!-- bootstrap datepicker -->
    <link rel="stylesheet" href="<?php echo e(asset('bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <!-- bootstrap datepicker -->
    <script src="<?php echo e(asset('bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>

    <script>
    function resetform() {
        // document.getElementById("nomor_polisi").value = "";
        elements = [];
        elements = document.getElementsByClassName("form-control");
        for(var i=0; i<elements.length ; i++){
            console.log(elements[i].name);
            if (elements[i].name == 'jenis_limbah' || elements[i].name == 'satuan'){
                elements[i].selectedIndex = 0 ;
            }else{
                elements[i].value = "" ;
            }
        }
        
    }

    $(function () {
        //Date picker
        $('.datepicker').datepicker({
            autoclose: true
        })
    })
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>