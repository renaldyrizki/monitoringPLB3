<?php $__env->startSection('breadcrumbs'); ?>
    <?php echo Breadcrumbs::render('pengangkutanLimbahB3_tabelData'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <div class="d-flex no-block">
                   <div class="ml-auto">
                        <a class="btn btn-sm btn-success btn-md" href="<?php echo e(route('backend::pengangkutanLimbahB3_add')); ?>">
                            <i class="fa fa-plus"></i> Buat
                        </a>
                        <a class="btn btn-sm btn-success btn-md" href="<?php echo e(route('backend::pengangkutanLimbahB3_add')); ?>">
                            <i class="fa fa-book"></i> Download Logbook
                        </a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                
                <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <i class="icon fa fa-check"></i> <?php echo e(session('success')); ?>

                </div>
                <?php endif; ?>

                

                <div class="table-responsive m-t-20">
                    <table class="table table-hover" >
                        <thead>
                            <tr>
                                <th>Aksi</th>
                                <th>No</th>
                                <th>Jenis Limbah B3 Yang Keluar</th>
                                <th>Tanggal Keluar</th>
                                <th>Jumlah Keluar</th>
                                <th>Tujuan Penyerahan</th>
                                <th>Nomor Manifest</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $no=0;?>
                        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <a class="btn btn-info btn-xs" title="Ubah" href="<?php echo e(route('backend::pengangkutanLimbahB3_edit', ['id' => $res->id_pengangkutan])); ?>"> Ubah
                                
                                    <i class="fa fa-pencil"></i>
                                </a>
                                <button class="btn btn-danger btn-xs" title="Hapus" onclick="deleteData(<?php echo e($res->id_pengangkutan); ?>)"> Hapus
                                
                                    <i class="glyphicon glyphicon-trash"></i>
                                </button>
                            </td>
                            <td>
                                <?php echo e($no + $data->firstItem()); ?>

                            </td>
                            <td>
                                <?php echo e($res->jenis_limbah); ?>

                            </td>
                            <td>
                                <?php echo e($res->tanggal_pengangkutan); ?>

                            </td>
                            <td>
                                <?php echo e($res->total_pengangkutan); ?>

                            </td>
                            <td>
                                <?php echo e($res->tujuan_pemanfaatan); ?>

                            </td>
                            <td>
                                <?php echo e($res->nomor_manifest); ?>

                            </td>
                        </tr>
                        <?php $no++;?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td>
                                Tidak ada data.
                            </td>
                        </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                    
                    <div class="text-center">
                        <?php echo e($data->links()); ?>

                    </div>

                    
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script type="text/javascript">
    function deleteData(id){
        console.log(id);
		$('#mdlHapus'+id).modal('show'); // show bootstrap modal
	}

    // function lihatFoto(url){
	// 	$("#fotona").attr("src", url);
	// 	$('#modalFoto').modal('show'); // show bootstrap modal
	// }
</script>

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div id="mdlHapus<?php echo e($res->id_pengangkutan); ?>" class="modal fade" tabindex="-1">
	<div class="modal-dialog">
		<div class="modal-content">

			<div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">Konfirmasi</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>

			<div class="modal-body">
				<div class="row">
					<div class="col-md-12">
						Apakah benar data akan di hapus?
					</div>
				</div>
			</div>

			<div class="modal-footer">
                <form method="POST" action="<?php echo e(route('backend::pengangkutanLimbahB3_delete', ['id'=>$res->id_pengangkutan])); ?>" accept-charset="UTF-8">
                    <input name="_method" type="hidden" value="DELETE">
                    <?php echo e(csrf_field()); ?>

                    <button type="button" class="btn btn-sm btn-primary" data-dismiss="modal">Cancel</button>

                    <input type="submit" class="btn btn-sm btn-danger" value="Hapus">
                </form>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.'.config('larakuy.theme_back').'.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>