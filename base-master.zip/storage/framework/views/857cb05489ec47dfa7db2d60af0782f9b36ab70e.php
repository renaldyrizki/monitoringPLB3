<?php $__env->startSection('breadcrumbs'); ?>
    <?php echo Breadcrumbs::render('penyimpananLimbahB3_tabelData'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <div class="d-flex no-block">
                    <div class="ml-auto">
                        <a class="btn btn-sm btn-success btn-md" href="<?php echo e(route('backend::permitsControl_add')); ?>">
                            <i class="fa fa-plus"></i> Tambah Data
                        </a>
                        <a class="btn btn-sm btn-success btn-md" href="<?php echo e(route('backend::kirimEmail_permits')); ?>">
                            <i class="fa fa-envelope"></i> Report Email
                        </a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                
                <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <i class="icon fa fa-check"></i> <?php echo e(session('success')); ?>

                </div>
                <?php endif; ?>
                <div id="filter" style="margin-top: 0.1in; margin-bottom: 0.1in;">
                    <form class="form-inline" action="<?php echo e(route('backend::permitsControl')); ?>" method="GET">
                    
                        <div class="form-group" row>
                            <input type="text" name="cari" class="form-control form-control-sm" placeholder="Cari Perusahaan" style="margin-left: 0; border-width: 1px;">
                        </div>
                        <div class="form-group" row>
                            <select name="jenis_perizinan" class="form-control">
                                <option disabled selected value> -- Jenis Perizinan -- </option>
                                <?php $__currentLoopData = $jenis_perizinan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value=<?php echo e($key); ?>><?php echo e($value); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </optgroup>
                            </select>
                        </div>
                        <div class="form-group" row>
                            <select name="status" class="form-control">
                                <option disabled selected value> -- Status -- </option>
                                <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value=<?php echo e($key); ?>><?php echo e($value); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group" row>
                            <select name="sort_by" class="form-control">
                                <option disabled selected value> -- Sort By -- </option>
                                <?php $__currentLoopData = $sort_by; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value=<?php echo e(str_replace(" ", "_", strtolower($value))); ?>><?php echo e($value); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group" row>
                            <select name="sort" class="form-control">
                                <option value='asc'>Ascending</option>
                                <option value='desc'>Descending</option>
                            </select>
                        </div>
                        <div class="form-group" style="margin:5px">
                            <button type="submit" class="btn btn-success btn-sm">
                                <i class="fa fa-search"></i> Cari
                            </button>
                            
                            <a class="btn btn-success btn-sm" role="button" href=""><i class="fa fa-recycle"></i> Reset</a>
                        </div>
                    </form>
                </div>

                <div class="table-responsive m-t-20">
                    <table class="table table-hover" >
                        <thead>
                            <tr>
                                <th>Aksi</th>
                                <th>No</th>
                                <th>No Surat Keputusan</th>
                                <th>Nama Perusahaan</th>
                                <th>Tanggal Terbit</th>
                                <th>Tanggal Habis Berlaku</th>
                                <th>Jenis Perizinan</th>
                                <th>Lampiran</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $no=0;?>
                        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                        <a class="btn btn-info btn-xs" title="Ubah" href="<?php echo e(route('backend::permitsControl_edit', ['id' => $res->id_permits])); ?>"> Ubah
                                        
                                            <i class="fa fa-pencil"></i>
                                        </a>
                                        <button class="btn btn-danger btn-xs" title="Hapus" onclick="deleteData(<?php echo e($res->id_permits); ?>)"> Hapus
                                        
                                            <i class="glyphicon glyphicon-trash"></i>
                                        </button>
                                    </td>
                                <td>
                                    <?php echo e($no + $data->firstItem()); ?>

                                </td>
                                <td>
                                    <?php echo e($res->no_surat_keputusan); ?>

                                </td>
                                <td>
                                    <?php echo e($res->nama_perusahaan); ?>

                                </td>
                                <td>
                                    <?php echo e($res->tanggal_terbit); ?>

                                </td>
                                <td>
                                    <?php echo e($res->tanggal_habis_berlaku); ?>

                                </td>
                                <td>
                                    <?php echo e($res->jenis_perizinan); ?>

                                </td>
                                <td>
                                    <?php if($res->lampiran_dokumen): ?>
                                        <a href="<?php echo e(route('backend::permitsControl_download', ['id' => $res->id_permits])); ?>"><u>Download</u></a>
                                    <?php else: ?>
                                        Tidak Ada
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php  
                                        $terbit = date("Y-m-d", strtotime($res->tanggal_terbit));
                                        $habis = date("Y-m-d", strtotime($res->tanggal_habis_berlaku));
                                        $batas = date("Y-m-d", strtotime("-2 month", strtotime($res->tanggal_habis_berlaku)));
                                        $hariIni = date("Y-m-d", strtotime("now"));
                                     ?>
                                    <?php if( ($hariIni > $batas) and ($hariIni <= $habis)): ?>
                                        Warning
                                    <?php elseif($hariIni > $habis): ?>
                                        Expired
                                    <?php elseif($hariIni <= $batas): ?>
                                        OK
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php $no++;?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6">
                                Tidak ada data.
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="text-center">
                        <?php echo e($data->links()); ?>

                    </div>
                    
                    
                    
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script type="text/javascript">
    function deleteData(id){
        console.log(id);
		$('#mdlHapus'+id).modal('show'); // show bootstrap modal
	}
</script>

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div id="mdlHapus<?php echo e($res->id_permits); ?>" class="modal fade" tabindex="-1">
	<div class="modal-dialog">
		<div class="modal-content">

			<div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">Konfirmasi</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>

			<div class="modal-body">
				<div class="row">
					<div class="col-md-12">
                        Apakah benar data akan di hapus?
					</div>
				</div>
			</div>

			<div class="modal-footer">
                <form method="POST" action="<?php echo e(route('backend::permitsControl_delete', ['id'=>$res->id_permits])); ?>" accept-charset="UTF-8">
                    <input name="_method" type="hidden" value="DELETE">
                    <?php echo e(csrf_field()); ?>

                    <button type="button" class="btn btn-sm btn-primary" data-dismiss="modal">Cancel</button>

                    <input type="submit" class="btn btn-sm btn-danger" value="Hapus">
                </form>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.'.config('larakuy.theme_back').'.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>