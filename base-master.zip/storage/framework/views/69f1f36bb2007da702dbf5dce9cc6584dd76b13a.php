<?php $__env->startSection('breadcrumbs'); ?>
    <?php echo Breadcrumbs::render('pengangkutanLimbah'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    
    

    <?php echo e(csrf_field()); ?>

    <form class="form-horizontal">
        <div class="form-group" row>
            <label for="jenis_limbah" class="col-sm-2 control-label">Jenis Limbah</label>
            <div class="col-sm-6">
                <select name="jenis_limbah" class="form-control" onchange="ubahKategori(this.value);">
                    <?php $__currentLoopData = $jenis_limbah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value=<?php echo e($key); ?>><?php echo e($key); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
    
        <div class="form-group">
            <label for="tanggal_pengangkutan" class="col-sm-2 control-label">Tanggal Pengangkutan</label>
            <div class="col-sm-6">
                <input type="text" name="tanggal_pengangkutan" data-date-format='yyyy-mm-dd' value="" class="form-control pull-right datepicker" id="tanggal_pengangkutan" placeholder="Tanggal Pengangkutan">
            </div>
        </div>

        <div class="form-group">
            <label for="berat_kendaraan" class="col-sm-2 control-label">Total Pengangkutan</label>
            <div class="col-sm-6">
                <input type="number" min=0 name="berat_kendaraan" id="berat_kendaraan" class="form-control" value="" placeholder="Berat dalam satuan KG">
            </div>
        </div>

        <div class="form-group">
            <label for="nomor_manifest" class="col-sm-2 control-label">Nomor Manifest</label>
            <div class="col-sm-6">
                <input type="text" name="nomor_manifest" id="nomor_manifest" class="form-control" value="" placeholder="Nomor Manifest">
            </div>
        </div>

        <div class="form-group">
            <label for="perusahaan_pengangkutan" class="col-sm-2 control-label">Perusahaan Pengangkutan</label>
            <div class="col-sm-6">
                <input type="text" name="perusahaan_pengangkutan" id="perusahaan_pengangkutan" class="form-control" value="" placeholder="Perusahaan Pengangkutan">
            </div>
        </div>

        <div class="form-group">
            <label for="tujuan_pemanfaatan" class="col-sm-2 control-label">Tujuan Pemanfaatan</label>
            <div class="col-sm-6">
                <input type="text" name="tujuan_pemanfaatan" id="tujuan_pemanfaatan" class="form-control" value="" placeholder="Tujuan Pemanfaatan">
            </div>
        </div>
        
        <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
                <input type="submit" class="btn btn-success btn-md" name="simpan" value="Simpan">
                
                
                <a class="btn btn-primary" role="button" onclick="resetform()">Reset</a>
            </div>
        </div>
      </form>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <!-- bootstrap datepicker -->
    <link rel="stylesheet" href="<?php echo e(asset('bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <!-- bootstrap datepicker -->
    <script src="<?php echo e(asset('bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>

    <script>
    function resetform() {
        // document.getElementById("nomor_polisi").value = "";
        elements = [];
        elements = document.getElementsByClassName("form-control");
        for(var i=0; i<elements.length ; i++){
            elements[i].value = "" ;
        }
        
    }

    $(function () {
        //Date picker
        $('.datepicker').datepicker({
            autoclose: true
        })
    })
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>