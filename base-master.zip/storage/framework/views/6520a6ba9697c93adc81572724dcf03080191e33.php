<?php $__env->startSection('breadcrumbs'); ?>
    <?php echo Breadcrumbs::render('pengangkutanLimbahB3'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    
    

<form action="<?php echo e(route('backend::manifestControl_update', ['id' => $data->id_pengangkutan])); ?>" class="form-horizontal" method="post">
    <?php echo e(csrf_field()); ?>

    <input name="_method" type="hidden" value="PATCH">
    
        <div class="form-group" row>
            <label for="jenis_limbah" class="col-sm-2 control-label">Jenis Limbah</label>
            <div class="col-sm-6">
                <select name="jenis_limbah" class="form-control" disabled>
                    <?php $__currentLoopData = $jenis_limbah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value=<?php echo e($key); ?> <?php echo e((!empty($data))? ($data->jenis_limbah==$value) ? ' selected' : '' : ''); ?>><?php echo e($value); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="form-group" row>
            <label for="status_pengangkutan" class="col-sm-2 control-label">Status Pengangkutan</label>
            <div class="col-sm-6">
                <select name="status_pengangkutan" class="form-control">
                    <option value="Diterima" <?php echo e((!empty($data))? ($data->status_pengangkutan=="True") ? ' selected' : '' : ''); ?>>Diterima</option>
                    <option value="Belum Diterima" <?php echo e((!empty($data))? ($data->status_pengangkutan=="False") ? ' selected' : '' : ''); ?>>Belum Diterima</option>
                </select>
                
            </div>
        </div>
    
        <div class="form-group">
            <label for="tanggal_pengangkutan" class="col-sm-2 control-label">Tanggal Pengangkutan</label>
            <div class="col-sm-6">
                <input disabled type="text" name="tanggal_pengangkutan" data-date-format='yyyy-mm-dd' value="<?php echo e((!empty($data))? $data->tanggal_pengangkutan : ''); ?>" class="form-control pull-right datepicker" id="tanggal_pengangkutan" placeholder="Tanggal Pengangkutan">
            </div>
        </div>

        <div class="form-group">
            <label for="total_pengangkutan" class="col-sm-2 control-label">Total Pengangkutan</label>
            <div class="col-sm-4">
                <input disabled type="number" min=0 name="total_pengangkutan" id="total_pengangkutan" class="form-control" value="<?php echo e((!empty($data))? $data->total_pengangkutan : ''); ?>" placeholder="Total Pengangkutan">
            </div>
            <div class="col-sm-2">
                <select name="satuan" class="form-control" disabled>
                    <?php $__currentLoopData = $satuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value=<?php echo e($sat); ?> ><?php echo e($sat); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="form-group">
            <label for="nomor_manifest" class="col-sm-2 control-label">Nomor Manifest</label>
            <div class="col-sm-6">
                <input disabled type="text" name="nomor_manifest" id="nomor_manifest" class="form-control" value="<?php echo e((!empty($data))? $data->nomor_manifest : ''); ?>" placeholder="Nomor Manifest">
            </div>
        </div>

        <div class="form-group">
            <label for="perusahaan_pengangkut" class="col-sm-2 control-label">Perusahaan Pengangkutan</label>
            <div class="col-sm-6">
                <input disabled type="text" name="perusahaan_pengangkut" id="perusahaan_pengangkut" class="form-control" value="<?php echo e((!empty($data))? $data->perusahaan_pengangkut : ''); ?>" placeholder="Perusahaan Pengangkut">
            </div>
        </div>

        <div class="form-group">
            <label for="tujuan_pemanfaatan" class="col-sm-2 control-label">Tujuan Pemanfaatan</label>
            <div class="col-sm-6">
                <input disabled type="text" name="tujuan_pemanfaatan" id="tujuan_pemanfaatan" class="form-control" value="<?php echo e((!empty($data))? $data->tujuan_pemanfaatan : ''); ?>" placeholder="Tujuan Pemanfaatan">
            </div>
        </div>

        <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
                <input type="submit" class="btn btn-success btn-md" name="simpan" value="Update">
                
                
                <a class="btn btn-primary" role="button" onclick="resetform()">Reset</a>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <!-- bootstrap datepicker -->
    <link rel="stylesheet" href="<?php echo e(asset('bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <!-- bootstrap datepicker -->
    <script src="<?php echo e(asset('bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>

    <script>
    function resetform() {
        // document.getElementById("nomor_polisi").value = "";
        elements = [];
        elements = document.getElementsByClassName("form-control");
        for(var i=0; i<elements.length ; i++){
            console.log(elements[i].name);
            if (elements[i].name == 'jenis_limbah' || elements[i].name == 'satuan'){
                elements[i].selectedIndex = 0 ;
            }else{
                elements[i].value = "" ;
            }
        }
        
    }

    $(function () {
        //Date picker
        $('.datepicker').datepicker({
            autoclose: true
        })
    })
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>