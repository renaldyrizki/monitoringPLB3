<?php 
    $user = Auth::user();
 ?>

<?php if(($items = app('larakuy.backend.menu')->roots()) && (!$items->isEmpty()) && $user->isAdmin==1 ): ?>
    <?php echo $__env->make('layouts.backend.sidebar_item', ['items' => $items], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>

<?php if(($items = app('larakuy.user.menu')->roots()) && $user->isAdmin==0 ): ?>
    <?php echo $__env->make('layouts.backend.sidebar_item', ['items' => $items], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>