<?php $__env->startSection('breadcrumbs'); ?>
    <?php echo Breadcrumbs::render('manifestControl'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive m-t-20">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Action</th>
                                <th>No</th>
                                <th>Nomor Manifest</th>
                                <th>Perusahaan Pemanfaat</th>
                                <th>Jenis Limbah</th>
                                <th>Tanggal Pengangkutan</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $no=0;?>
                        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <a class="btn btn-info btn-xs" title="Ubah" href="#"> Ubah
                                    <i class="fa fa-pencil"></i>
                                </a>
                                <button class="btn btn-danger btn-xs" title="Hapus"> Hapus
                                    <i class="fa fa-trash"></i>
                                </button>
                            </td>
                            <td>
                                <?php echo e($no + $data->firstItem()); ?>

                            </td>
                            <td>
                                <?php echo e($res->nomor_manifest); ?>

                            </td>
                            <td>
                                <?php echo e($res->perusahaan_pengangkut); ?>

                            </td>
                            <td>
                                <?php echo e($res->jenis_limbah); ?>

                            </td>
                            <td>
                                <?php echo e($res->tanggal_pengangkutan); ?>

                             </td>
                            <td>
                                <?php if($res->status_pengangkutan==1): ?>
                                    Diterima
                                <?php else: ?>
                                    Belum Diterima
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php $no++;?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6">
                                Tidak ada data.
                            </td>
                        </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>

                    <div class="text-center">
                        <?php echo e($data->links()); ?>

                    </div>

                    
                    
                    
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<style>
  /* .table>thead>tr>th {
    border-bottom: 1px solid black;
  } */
</style>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<script type="text/javascript">
    function deleteData(id){
        console.log(id);
		$('#mdlHapus'+id).modal('show'); // show bootstrap modal
	}
</script>




<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.'.config('larakuy.theme_back').'.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>