<?php $__env->startSection('breadcrumbs'); ?>
    <?php echo Breadcrumbs::render('truckPermits'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <div class="d-flex no-block">
                    <div class="ml-auto" style="margin-left: 0.2in; margin-bottom: 10px;">
                        <a class="btn btn-sm btn-success btn-md" href="<?php echo e(route('backend::truckPermits_add')); ?>">
                            <i class="fa fa-plus"></i> Tambah Data Truk
                        </a>
                        <a class="btn btn-sm btn-success btn-md" href="<?php echo e(route('backend::kirimEmail_truck')); ?>">
                            <i class="fa fa-envelope"></i> Report Email
                        </a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <i class="icon fa fa-check"></i> <?php echo e(session('success')); ?>

                </div>
                <?php endif; ?>
                <div class="table-responsive m-t-20">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Aksi</th>
                                <th>No</th>
                                <th>Nomor Truk</th>
                                <th>Perusahaan Transporter</th>
                                <th>Lampiran</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $no=0;?>
                        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $truck): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <a class="btn btn-info btn-xs" title="Ubah" href="<?php echo e(route('backend::truckPermits_edit', ['id' => $truck->id_truck])); ?>"> Ubah
                                        <i class="fa fa-pencil"></i>
                                    </a>
                                    <button class="btn btn-danger btn-xs" title="Hapus" onclick="deleteData(<?php echo e($truck->id_truck); ?>)"> Hapus
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </td>
                                <td style="width: 20px">
                                    <?php echo e($no + $data->firstItem()); ?>

                                </td>
                                <td>
                                    <?php echo e($truck->no_polisi); ?> 
                                </td>
                                <td>
                                    <?php echo e($truck->perusahaan_transporter); ?> 
                                </td>
                                <td>
                                    <?php if($truck->izin_pengangkutan_file or $truck->dokumen_lingkungan_file or $truck->mou_file or $truck->kartu_pengawasan_file): ?>
                                        <a href="<?php echo e(route('backend::truckPermits_downloads', ['id' => $truck->id_truck])); ?>"><u>Download</u></a>
                                    <?php else: ?>
                                        Tidak Ada
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php 
                                        $file = array('izin_pengangkutan', 'dokumen_lingkungan', 'mou','kartu_pengawasan');
                                        $status = 1;
                                        $i = 0;
                                        while ($i < count($file) and $status==1) {
                                            if($truck[$file[$i]."_tanggal_terbit"] and $truck[$file[$i]."_tanggal_habis"] and $truck[$file[$i]."_file"]){
                                                $habis = date("Y-m-d", strtotime($truck[$file[$i]."_tanggal_habis"]));
                                                $hariIni = date("Y-m-d", strtotime("now"));
                                                if ($hariIni > $habis) {
                                                    $status = 0;
                                                };
                                            }else{
                                                $status = 0;
                                            };
                                            $i = $i+1;
                                        };
                                        if($status == 1){
                                            echo "Lengkap";
                                        }else{
                                            echo "Tidak Lengkap";
                                        };
                                     ?>
                                </td>
                            </tr>
                            <?php $no++;?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6">
                                    Tidak ada data.
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="col-md-12 text-center">
                        <?php echo e($data->links()); ?>

                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<style>
  table {
    /* border-collapse: collapse; */
  }
  
  table, th, td, tr, thead, tbody, .table>thead>tr>th {
    border-bottom: 1px solid black;
  }
  .table{
    width: 98%;
    max-width: 98%;
    margin-right: 1%;
    margin-left: 1%;
  }


  /* .table>thead>tr>th {
    border-bottom: 1px solid black;
  } */
</style>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<script type="text/javascript">
    function deleteData(id){
        console.log(id);
		$('#mdlHapus'+id).modal('show'); // show bootstrap modal
	}
</script>


<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div id="mdlHapus<?php echo e($res->id_truck); ?>" class="modal fade" tabindex="-1">
	<div class="modal-dialog">
		<div class="modal-content">

			<div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">Konfirmasi</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>

			<div class="modal-body">
				<div class="row">
					<div class="col-md-12">
                        Apakah benar data akan di hapus?
					</div>
				</div>
			</div>

			<div class="modal-footer">
                <form method="POST" action="<?php echo e(route('backend::truckPermits_delete', ['id'=>$res->id_truck])); ?>" accept-charset="UTF-8">
                    <input name="_method" type="hidden" value="DELETE">
                    <?php echo e(csrf_field()); ?>

                    <button type="button" class="btn btn-sm btn-primary" data-dismiss="modal">Cancel</button>

                    <input type="submit" class="btn btn-sm btn-danger" value="Hapus">
                </form>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.'.config('larakuy.theme_back').'.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>