<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
  border: 1px solid black;
}
</style>
</head>
<body>

<h3>Hey Sir/Madam,</h3>
<p>Berikut Daftar <?php echo e($jenis_izin); ?> Warning dan Expired untuk area <?php echo e($area); ?>.</p>
<div class="table-responsive m-t-20">
    <table class="table table-hover">
        <thead>
            <tr>
                <th>No</th>
                <th>Item</th>
            </tr>
        </thead>
        <tbody>
        <?php $no=0; ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <?php echo e($no); ?>

            </td>
            <td>
              ja
              
            </td>
        </tr>
        <?php $no++; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<p>Mohon segera meng-update lisensi yang sudah melewati masa berlakunya melalui link: <a href="<?php echo e($link); ?>"><?php echo e($link); ?></a></p>
<p>Untuk informasi lebih lanjut dapat menghubungi vie email berikut: <a href="mailto:<?php echo e($contact_email); ?>"><?php echo e($contact_email); ?></a> - <?php echo e($contact_name); ?></p>
<p>Email ini terkirim secara otomatis melalui LCS, mohon untuk tidak me-reply email ini.</p>
<p>@2018  All Right Reserved | Licensi Control System - GA Operation 3</p>
</body>
</html>
