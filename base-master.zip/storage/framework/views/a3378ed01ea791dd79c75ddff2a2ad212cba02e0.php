<?php $__env->startSection('breadcrumbs'); ?>
    <?php echo Breadcrumbs::render('permitsControl'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    Welcome <?php echo e(Auth::user()->name); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>