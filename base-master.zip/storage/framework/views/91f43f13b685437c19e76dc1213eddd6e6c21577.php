<?php $__env->startSection('breadcrumbs'); ?>
    <?php echo Breadcrumbs::render('tambahTruck'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    
    

    <?php echo e(csrf_field()); ?>

    <form class="form-horizontal">
        <div class="form-group" row>
            <label for="jenis_kendaraan" class="col-sm-2 control-label">Jenis Kendaraan</label>
            <div class="col-sm-6">
                <select name="kategori" class="form-control" onchange="ubahKategori(this.value);">
                    <?php $__currentLoopData = $jenis_kendaraan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value=<?php echo e($key); ?>><?php echo e($key); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
    
        <div class="form-group">
            <label for="nomor_polisi" class="col-sm-2 control-label">Nomor Polisi</label>
            <div class="col-sm-6">
                <input type="text" maxlength="7" name="nomor_polisi" id="nomor_polisi" class="form-control" value="" placeholder="Nomor Polisi">
            </div>
        </div>

        <div class="form-group">
            <label for="nomor_polisi" class="col-sm-2 control-label">Perusahaan Transporter</label>
            <div class="col-sm-6">
                <input type="text" name="perusahaan_transporter" id="perusahaan_transporter" class="form-control" value="" placeholder="Perusahaan Transporter">
            </div>
        </div>

        <div class="form-group">
            <label for="nomor_polisi" class="col-sm-2 control-label">Jenis dan Kode Limbah</label>
            <div class="col-sm-6">
                <input type="text" name="jk_limbah" id="jk_limbah" class="form-control" value="" placeholder="Jenis dan Kode Limbah">
            </div>
        </div>

        <div class="form-group">
            <label for="nomor_polisi" class="col-sm-2 control-label">Berat Max Kendaraan</label>
            <div class="col-sm-6">
                <input type="number" min=0 name="berat_kendaraan" id="berat_kendaraan" class="form-control" value="" placeholder="Berat dalam satuan KG">
            </div>
        </div>

        <div class="form-group">
            <label for="nomor_polisi" class="col-sm-2 control-label">Berat Limbah Dapat Diangkut</label>
            <div class="col-sm-6">
                <input type="number" min=0 name="berat_limbah" id="berat_limbah" class="form-control" value="" placeholder="Berat dalam satuan KG">
            </div>
        </div>

        <h3 style="text-align: center">Lampiran</h3>

        <div class="form-group">
            <label for="izin_pengangkutan" class="col-sm-2 control-label">Izin Pengangkutan</label>
            <div class="col-sm-2">
                <input type="text" name="izin_pengangkutan" id="izin_pengangkutan" class="form-control" value="" placeholder="Nomor">
            </div>
            <div class="col-sm-2">
                <input type="text" name="tanggal_terbit" data-date-format='yyyy-mm-dd' value="" class="form-control pull-right datepicker" id="tanggal_terbit_pengangkutan" placeholder="Tanggal terbit">
            </div>
            <div class="col-sm-2">
                <input type="text" name="tanggal_habis" data-date-format='yyyy-mm-dd' value="" class="form-control pull-right datepicker" id="tanggal_habis_pengangkutan" placeholder="Tanggal Habis Berlaku">
            </div>
            <div class="col-sm-2">
                    <div class="form-group">
                        <input type="file" accept="application/pdf, image/jpeg, image/jpg" name="file_izin_pengangkutan" class="form-control">
                    </div>
            </div>
        </div>

        <div class="form-group">
            <label for="dokumen_lingkungan" class="col-sm-2 control-label">Dokumen Lingkungan</label>
            <div class="col-sm-2">
                <input type="text" name="dokumen_lingkungan" id="dokumen_lingkungan" class="form-control" value="" placeholder="Nomor">
            </div>
            <div class="col-sm-2">
                <input type="text" name="tanggal_terbit" data-date-format='yyyy-mm-dd' value="" class="form-control pull-right datepicker" id="tanggal_terbit_dokLingkungan" placeholder="Tanggal terbit">
            </div>
            <div class="col-sm-2">
                <input type="text" name="tanggal_habis" data-date-format='yyyy-mm-dd' value="" class="form-control pull-right datepicker" id="tanggal_habis_dokLingkungan" placeholder="Tanggal Habis Berlaku">
            </div>
            <div class="col-sm-2">
                    <div class="form-group">
                        <input type="file" accept="application/pdf, image/jpeg, image/jpg" name="file_dokumen_lingkungan" class="form-control">
                    </div>
            </div>
        </div>
        <div class="form-group">
            <label for="mou" class="col-sm-2 control-label">MOU</label>
            <div class="col-sm-2">
                <input type="text" name="mou" id="mou" class="form-control" value="" placeholder="Nomor">
            </div>
            <div class="col-sm-2">
                <input type="text" name="tanggal_terbit" data-date-format='yyyy-mm-dd' value="" class="form-control pull-right datepicker" id="tanggal_terbit_mou" placeholder="Tanggal terbit">
            </div>
            <div class="col-sm-2">
                <input type="text" name="tanggal_habis" data-date-format='yyyy-mm-dd' value="" class="form-control pull-right datepicker" id="tanggal_habis_mou" placeholder="Tanggal Habis Berlaku">
            </div>
            <div class="col-sm-2">
                    <div class="form-group">
                        <input type="file" accept="application/pdf, image/jpeg, image/jpg" name="file_mou" class="form-control">
                    </div>
            </div>
        </div>
        <div class="form-group">
            <label for="kartu_pengawasan" class="col-sm-2 control-label">Kartu Pengawasan</label>
            <div class="col-sm-2">
                <input type="text" name="kartu_pengawasan" id="kartu_pengawasan" class="form-control" value="" placeholder="Nomor">
            </div>
            <div class="col-sm-2">
                <input type="text" name="tanggal_terbit" data-date-format='yyyy-mm-dd' value="" class="form-control pull-right datepicker" id="tanggal_terbit_pengawasan" placeholder="Tanggal terbit">
            </div>
            <div class="col-sm-2">
                <input type="text" name="tanggal_habis" data-date-format='yyyy-mm-dd' value="" class="form-control pull-right datepicker" id="tanggal_habis_pengawasan" placeholder="Tanggal Habis Berlaku">
            </div>
            <div class="col-sm-2">
                    <div class="form-group">
                        <input type="file" accept="application/pdf, image/jpeg, image/jpg" name="file_pengawasan" class="form-control" >
                    </div>
            </div>
        </div>
        
        <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
                <input type="submit" class="btn btn-success btn-md" name="simpan" value="Simpan">
                
                
                <a class="btn btn-primary" role="button" onclick="resetform()">Reset</a>
            </div>
        </div>
      </form>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <!-- bootstrap datepicker -->
    <link rel="stylesheet" href="<?php echo e(asset('bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <!-- bootstrap datepicker -->
    <script src="<?php echo e(asset('bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>

    <script>
    function resetform() {
        // document.getElementById("nomor_polisi").value = "";
        elements = [];
        elements = document.getElementsByClassName("form-control");
        for(var i=0; i<elements.length ; i++){
            elements[i].value = "" ;
        }
        
    }

    $(function () {
        //Date picker
        $('.datepicker').datepicker({
            autoclose: true
        })
    })
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>