<?php
namespace App\Classes;

use Lavary\Menu\Menu as BaseMenu;

class Menu extends BaseMenu{


}