<?php

return [

	// 'view' => 'breadcrumbs::bootstrap3',
	'view' => 'layouts.backend.breadcrumbs',

];
