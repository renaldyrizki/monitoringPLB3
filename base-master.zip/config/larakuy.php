<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Prefix Path Name
    |--------------------------------------------------------------------------
    |
    | This value is the path name of your backend administrator application.
    */
    'prefix_admin' => 'backend',
    'footer'        => 'Copyright &copy; '.date('Y').' Renaldy',
];